﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ПР_13.Classes
{
    class ConnectHelper
    {
        public static List<Price> prices = new List<Price>();
        public static void ReadListFromFile(string filename)
        {
            StreamReader streamReader = new StreamReader(filename, Encoding.UTF8);
            while (!streamReader.EndOfStream)
            {
                string[] items = streamReader.ReadLine().Split(';');
                Price price = new Price()
                {
                    NameProduct = items[0].Trim(),
                    NameShop = items[1].Trim(),
                    PriceProduct = double.Parse(items[2].Trim()),
                    CountProduct = int.Parse(items[3].Trim())
                };
                prices.Add(price);
            }       
        }
        public static void SaveListToFile(string filename)
        {
            StreamWriter streamWriter = new StreamWriter(filename, false, Encoding.UTF8);
            foreach (Price ph in prices)
            {
                streamWriter.WriteLine($"{ph.NameProduct};{ph.NameShop};{ph.PriceProduct};{ph.CountProduct}");
            }
            streamWriter.Close();
        }
    }
}
